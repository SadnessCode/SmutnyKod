/*
 * LogSort.hpp
 *
 *  Created on: Jan 20, 2016
 *       Created by Hubert Kamienik (p637)
 *      e-mail: p637@ericpol.com
 */
#ifndef LOGSORT_HPP_
#define LOGSORT_HPP_
#include <vector>
#include <time.h>
#include <string>



class LogSort
{      
   public:
	struct IntStruct
	   {		
              long long int a;
	      long  line;
	   };
   private:
	int iter;
	int p;
	int NonLine;
	short int LineWithoutTime;
	std::string nameOfFile;
	int currentLine;  
        std::vector < int > container;
   public:
       std::vector <IntStruct * > LineContainer;
       IntStruct * ptr;
       void  Log (std::string name);
       void  Sort (long int lewy, long int prawy);
       void  Preprocess (std::string formula,long LineNumber );
       void WriteToFile ();
       std::string GetStringLine(int LineNumber,std::fstream & File,int i,std::ofstream & NewFile);
};
#endif /* LOGSORT_HPP_ */
