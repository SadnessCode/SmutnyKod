/*
 * LogAnalysys.hpp
 *
 *  Created on: Jan 15, 2016
 *       Created by Hubert Kamienik (p637)
 *      e-mail: p637@ericpol.com
 */
#ifndef LOGANALYSYS_HPP_
#define LOGANALYSYS_HPP_
#include <string>
class LogAnalysys
{
        
	struct word
	{
		bool flag;
		std::string  word_char;
		std::string  reg;
	};
	int NumberOfArguments;
	char ** HandleToArguments;
	std::string OutString;
	std::string retu;
	void set_word (word * name,int number,std::string & re);
	void set_reg (word * name,int number,char ** argc);
	void if_match (word * name , int number,std::string & word);
	public:
	LogAnalysys (int Number,char ** a);
	std::string  do_it (std::string & LineOfFile);
};
#endif /* LOGANALYSYS_HPP_ */
